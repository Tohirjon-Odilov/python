num = int(input("Ikki xonali son kiriting: "))
print((num%10)*10+num//10)