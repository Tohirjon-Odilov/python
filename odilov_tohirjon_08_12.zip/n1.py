test = input("Qiymat kiriting: ")
print(type(test))