# num1 = int(input("Son kiriting: "))
# num2 = int(input("Son kiriting: "))

num1,num2 = int(input("Son kritit: ")), int(input("Son kirit: "))

print((num1 + num2) // 2) 