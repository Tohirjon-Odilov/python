# P11:

# Ixtiyoriy sonlardan iborat listni bitta songa aylantirib qo'ying

list1 = [19, 8, 2003, 3000]
list2 = ""

for i in list1:
    list2 += str(i)

print(int(list2))
