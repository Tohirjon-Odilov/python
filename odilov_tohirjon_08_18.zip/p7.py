numbers1 = [2, -1, 5, 3, 8, -4, 6, 7, 8, 9]
numbers2 = [1, 6, 7, -3, -9, -4, -5]

for i in numbers1:
    if i in numbers2:
        print(i, end=' ')
