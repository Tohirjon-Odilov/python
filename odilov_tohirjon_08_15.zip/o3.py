n = int(input("salom"))
