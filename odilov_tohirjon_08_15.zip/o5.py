i, count = 1, 0

while i <= 1000:
    count = 0
    j = 1
    while j <= i:
        if (i % j) == 0:
            count += 1
        j += 1
    if count == 9:
        print(i, end=" ")
    i += 1
