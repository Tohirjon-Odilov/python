str = input("So'z kiriting: ")

print(True if str[::-1] == str else False)