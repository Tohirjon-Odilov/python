num, i = 100, 0

while i <= 100:
    if str(i).find('3') != -1:
        print(i, end=" ")
    i += 1
