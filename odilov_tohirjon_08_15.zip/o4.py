num  = int(input("Son kiriting: "))

i = 1

count = 1

while i <= 1000:
    while count <= i: