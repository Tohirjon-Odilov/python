n = int(input("Son kiriting: "))
print("Toq" if n%2 else "Juft")

