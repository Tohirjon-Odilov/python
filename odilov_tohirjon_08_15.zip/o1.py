n = int(input("Son kiriting: ")) 
m = int(input("Son kiriting: "))

# if n % 2:
#     print('qora' if m % 2 else 'oq')
# else:
#     print('oq' if m % 2 else 'qora')


# update code!!!
# if (n+m)%2:
#     print("oq")
# else:
#     print("qora")


# variant 2 by teacher
if n % 2 == m % 2:
    print("Qora")
else:
    print("Oq")