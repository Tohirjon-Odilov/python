# Q1:
# Berilgan set va list ni qo'shib qo'ying (xuddi rasmdagidek)

sample_set = {'yellow', 'orange', 'black'}
sample_list = ['blue', 'green', 'red']

print(sample_set.union(sample_list))
