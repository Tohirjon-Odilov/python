# Q5:

# Dictionary da 200 borligini aniqlang, bor bo'lsa "bor", aks holda "yo'q" ni
# ekranga chiqaring

sample_dict = {"a": 100, "b": 200, "c": 300}

if 200 in sample_dict.values():
    print("bor")
else:
    print("yo'q")
