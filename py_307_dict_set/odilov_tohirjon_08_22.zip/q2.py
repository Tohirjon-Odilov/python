# Q2:
# Ikkita set da ham bor qiymatlarni ekranga chiqaring (xuddi rasmdagidek)

set1 = {23, 34, 45, 56, 67, 90}
set2 = {90, 34, 66, 12, 43, 23}

print(set1.intersection(set2))
