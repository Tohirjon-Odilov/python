# Q3:

# Ikkala set ni qo'shgandan keyin unique qiymatlarni ekranga chiqaring
# (xuddi rasmdagidek)

set1 = {10, 20, 30, 40, 50}
set2 = {30, 40, 50, 60, 70}

set1.update(set2)
print(set1)
